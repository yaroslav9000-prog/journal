import "./Footer.css";

function Footer(): JSX.Element {
    return (
        <div className="Footer">
			<h2>Some Fancy footer</h2>
        </div>
    );
}

export default Footer;
