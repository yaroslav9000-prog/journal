import { Routes, Route } from "react-router-dom";
import "./Main.css";
import Switch from "../../Pages/Teammeetup/Teammeetup";
import Teams from "../../Pages/Teams/Teams";
import Home from "../../Pages/Home/Home";
import NotFound from "../../Pages/NotFound/NotFound";
import Teammeetup from "../../Pages/Teammeetup/Teammeetup";
import { useEffect, useState } from "react";
import AddMeetup from "../../Pages/AddMeetup/AddMeetup";



function Main(): JSX.Element {
    return (
        <div className="Main">
			<Routes>
                <Route index path="/" element={<Home/>}/>
                <Route path="/teams" element={<Teams/>}/>
                <Route path="/teams/meetups" element={<Teammeetup/>}/>
                <Route path="/teams/meetups/add" element={<AddMeetup/>}/>
                <Route path="/*" element={<NotFound/>}/>
            </Routes>
        </div>
    );
}

export default Main;
