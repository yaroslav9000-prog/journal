import { useEffect, useState } from "react";
import "./Teams.css";
import axios from "axios";




function Teams(): JSX.Element {
    const [teams,setTeams] = useState([]);
    useEffect(()=>{
        // axios.get("http://localhost:3500/api/teams")
        // .then(data=>console.log(data.data))
        fetch("http://localhost:3500/api/teams")
        .then(data=>console.log(data));
    },[]);
    
    return (
        <div className="Teams">
            <h1>Zaebalo</h1>
            
        </div>
    );
}

export default Teams;
