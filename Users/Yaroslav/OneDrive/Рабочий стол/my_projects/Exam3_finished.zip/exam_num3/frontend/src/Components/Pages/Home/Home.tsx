import "./Home.css";

function Home(): JSX.Element {
    return (
        <div className="Home">
			<h1>home page</h1>
        </div>
    );
}

export default Home;
