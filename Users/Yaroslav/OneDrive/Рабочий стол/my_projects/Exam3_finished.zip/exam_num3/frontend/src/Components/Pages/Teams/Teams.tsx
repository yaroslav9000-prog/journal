import { useEffect, useState } from "react";
import "./Teams.css";
// import axios from "axios";




function Teams(): JSX.Element {
    const [teams,setTeams] = useState<any>([]);
    useEffect(()=>{
        const fetchData = async()=>{
            const response = await fetch("http://localhost:3500/api/teams");
            const data = await response.json();
            setTeams(data);
        }
        fetchData();
    },[]);
    
    return (
        <div className="Teams">
            {teams.length > 0?
            
            teams.map((item:any, index:number)=>(
                <div key={index} className="Box">
                    <h3>{item.id}</h3>
                    <h3>ID: {item.dev_team_name}</h3>
                </div>
            )):
            <h1>Not working</h1>
        }
        </div>
    );
}

export default Teams;
