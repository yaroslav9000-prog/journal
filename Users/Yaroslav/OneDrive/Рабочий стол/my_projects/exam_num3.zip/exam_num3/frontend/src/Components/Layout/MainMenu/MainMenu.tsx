import "./MainMenu.css";
import {NavLink} from "react-router-dom"
function MainMenu(): JSX.Element {
    return (
        <div className="MainMenu">
			<NavLink to="/">Home Page</NavLink>
			<NavLink to="/api/teams">Teams list</NavLink>
			<NavLink to="/api/teams/id">Switch Server</NavLink>
        </div>
    );
}

export default MainMenu;
