export const config = {
    PORT: 3500,
    host: "localhost"
}