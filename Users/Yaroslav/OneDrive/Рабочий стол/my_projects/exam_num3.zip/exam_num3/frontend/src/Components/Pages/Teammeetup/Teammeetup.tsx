import { useEffect, useState } from "react";
import "./Teammeetup.css";
import axios from "axios";



function Teammeetup(): JSX.Element {
    const[id, setId] = useState(0);
    const onSubmit = async (currValue: number)=>{
        axios.post("http://localhost:3500/api/teams/status",currValue);
    }
    useEffect(()=>{
        // console.log(id);
    },[id])    
    return (
        <div className="Teammeetup">
			{/* <input type="number" onChange={(event)=>{setId(parseInt(event.target.value))}}/><br />
            <input type="submit" onClick={(id)=>{onSubmit(id)}} value={"submit"}/> */}
        </div>
    );
}

export default Teammeetup;
