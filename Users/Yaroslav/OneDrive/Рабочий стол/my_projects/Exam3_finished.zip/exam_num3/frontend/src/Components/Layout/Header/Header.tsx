import "./Header.css";

function Header(): JSX.Element {
    return (
        <div className="Header">
			<h1>Teams</h1>
        </div>
    );
}

export default Header;
