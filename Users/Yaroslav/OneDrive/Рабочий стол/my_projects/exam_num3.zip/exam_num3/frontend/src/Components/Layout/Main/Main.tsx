import { Routes, Route } from "react-router-dom";
import "./Main.css";
import Switch from "../../Pages/Teammeetup/Teammeetup";
import Teams from "../../Pages/Teams/Teams";
import Home from "../../Pages/Home/Home";



function Main(): JSX.Element {
    return (
        <div className="Main">
			<Routes>
                <Route index path="/" element={<Home/>}/>
                <Route path="/api/teams" element={<Teams/>}/>
                <Route path="/api/teams/" element={<Switch/>}/>
            </Routes>
        </div>
    );
}

export default Main;
